// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "1111111111111111111111111111111111",
    authDomain: "kahoot-repo.firebaseapp.com",
    projectId: "kahoot-repo",
    storageBucket: "kahoot-repo.firebasestorage.app",
    messagingSenderId: "168631042618",
    appId: "1:168631042618:web:46bb4a86c22ac2cfa7eb03"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
